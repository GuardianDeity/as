using System.Threading.Tasks;
using WebApplication1.Inventory.Domain.Model.Aggregates;
using WebApplication1.Inventory.Domain.Model.Commands;

namespace WebApplication1.Inventory.Interfaces.ACL
{
    /// <summary>
    /// Interface for the Inventory context facade.
    /// </summary>
    /// <remarks>Fernando Lizano</remarks>
    public interface IInventoryContextFacade
    {
        Task<Thing> CreateThingAsync(CreateThingCommand command);
        Task<Thing> GetThingByIdAsync(int id);
    }
}