﻿using WebApplication1.Inventory.Domain.Model.Aggregates;
using WebApplication1.Inventory.Domain.Model.ValueObjects;

namespace WebApplication1.Inventory.Interfaces.REST.Resources
{
    /// <summary>
    /// Resource representation of a Thing for API responses.
    /// </summary>
    /// <remarks>Fernando Lizano</remarks>
    public class ThingResource
    {
        public int Id { get; set; }
        public string SerialNumber { get; set; }
        public string Model { get; set; }
        public string OperationMode { get; set; }
        public decimal MaximumTemperatureThreshold { get; set; }
        public decimal MinimumHumidityThreshold { get; set; }

        public ThingResource(Thing thing)
        {
            Id = thing.Id;
            SerialNumber = thing.SerialNumber.ToString();
            Model = thing.Model;
            OperationMode = thing.OperationMode.ToString();
            MaximumTemperatureThreshold = thing.MaximumTemperatureThreshold;
            MinimumHumidityThreshold = thing.MinimumHumidityThreshold;
        }
    }
}