using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Inventory.Domain.Model.Commands;
using WebApplication1.Inventory.Interfaces.ACL;
using WebApplication1.Inventory.Interfaces.REST.Resources;

namespace WebApplication1.Inventory.Interfaces.REST
{
    [ApiController]
    [Route("api/v1/[controller]")]
    public class ThingsController : ControllerBase
    {
        private readonly IInventoryContextFacade _inventoryContextFacade;

        public ThingsController(IInventoryContextFacade inventoryContextFacade)
        {
            _inventoryContextFacade = inventoryContextFacade;
        }

        /// <summary>
        /// Creates a new Thing.
        /// </summary>
        /// <param name="command">The command to create a new Thing.</param>
        /// <returns>The created Thing.</returns>
        /// <remarks>Fernando Lizano</remarks>
        [HttpPost]
        [ProducesResponseType(typeof(ThingResource), 201)]
        public async Task<IActionResult> CreateThing([FromBody] CreateThingCommand command)
        {
            var thing = await _inventoryContextFacade.CreateThingAsync(command);
            var resource = new ThingResource(thing);
            return CreatedAtAction(nameof(GetThingById), new { id = thing.Id }, resource);
        }

        /// <summary>
        /// Retrieves a Thing by its ID.
        /// </summary>
        /// <param name="id">The ID of the Thing to retrieve.</param>
        /// <returns>The requested Thing.</returns>
        /// <remarks>Fernando Lizano</remarks>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(ThingResource), 200)]
        [ProducesResponseType(404)]
        public async Task<IActionResult> GetThingById(int id)
        {
            var thing = await _inventoryContextFacade.GetThingByIdAsync(id);
            if (thing == null)
                return NotFound();

            var resource = new ThingResource(thing);
            return Ok(resource);
        }
    }
}