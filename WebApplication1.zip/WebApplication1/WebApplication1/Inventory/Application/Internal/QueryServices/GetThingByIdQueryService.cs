﻿using System.Threading.Tasks;
using WebApplication1.Inventory.Domain.Model.Aggregates;
using WebApplication1.Inventory.Domain.Model.Queries;
using WebApplication1.Inventory.Domain.Repositories;

namespace WebApplication1.Inventory.Application.Internal.QueryServices
{
    /// <summary>
    /// Service for handling the retrieval of a Thing by its ID.
    /// </summary>
    /// <remarks>Fernando Lizano</remarks>
    public class GetThingByIdQueryService
    {
        private readonly IThingRepository _thingRepository;

        public GetThingByIdQueryService(IThingRepository thingRepository)
        {
            _thingRepository = thingRepository;
        }

        public async Task<Thing> ExecuteAsync(GetThingByIdQuery query)
        {
            return await _thingRepository.FindByIdAsync(query.Id);
        }
    }
}