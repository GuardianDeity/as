﻿using System.Threading.Tasks;
using WebApplication1.Inventory.Domain.Model.Aggregates;
using WebApplication1.Inventory.Domain.Model.Commands;
using WebApplication1.Inventory.Domain.Repositories;
using WebApplication1.Shared.Domain.Repositories;

namespace WebApplication1.Inventory.Application.Internal.CommandServices
{
    /// <summary>
    /// Service for handling the creation of a new Thing.
    /// </summary>
    /// <remarks>Fernando Lizano</remarks>
    public class CreateThingCommandService
    {
        private readonly IThingRepository _thingRepository;
        private readonly IUnitOfWork _unitOfWork;

        public CreateThingCommandService(IThingRepository thingRepository, IUnitOfWork unitOfWork)
        {
            _thingRepository = thingRepository;
            _unitOfWork = unitOfWork;
        }

        public async Task<Thing> ExecuteAsync(CreateThingCommand command)
        {
            var thing = new Thing(command.Model, command.MaximumTemperatureThreshold, command.MinimumHumidityThreshold);
            await _thingRepository.AddAsync(thing);
            await _unitOfWork.CompleteAsync();
            return thing;
        }
    }
}