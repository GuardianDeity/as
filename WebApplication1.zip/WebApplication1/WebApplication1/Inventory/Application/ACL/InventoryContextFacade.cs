using System.Threading.Tasks;
using WebApplication1.Inventory.Application.Internal.CommandServices;
using WebApplication1.Inventory.Application.Internal.QueryServices;
using WebApplication1.Inventory.Domain.Model.Aggregates;
using WebApplication1.Inventory.Domain.Model.Commands;
using WebApplication1.Inventory.Domain.Model.Queries;
using WebApplication1.Inventory.Interfaces.ACL;

namespace WebApplication1.Inventory.Application.ACL
{
    /// <summary>
    /// Facade for the Inventory context, providing access to Thing-related operations.
    /// </summary>
    /// <remarks>Fernando Lizano</remarks>
    public class InventoryContextFacade : IInventoryContextFacade
    {
        private readonly CreateThingCommandService _createThingCommandService;
        private readonly GetThingByIdQueryService _getThingByIdQueryService;

        public InventoryContextFacade(CreateThingCommandService createThingCommandService, GetThingByIdQueryService getThingByIdQueryService)
        {
            _createThingCommandService = createThingCommandService;
            _getThingByIdQueryService = getThingByIdQueryService;
        }

        public async Task<Thing> CreateThingAsync(CreateThingCommand command)
        {
            return await _createThingCommandService.ExecuteAsync(command);
        }

        public async Task<Thing> GetThingByIdAsync(int id)
        {
            return await _getThingByIdQueryService.ExecuteAsync(new GetThingByIdQuery(id));
        }
    }
}