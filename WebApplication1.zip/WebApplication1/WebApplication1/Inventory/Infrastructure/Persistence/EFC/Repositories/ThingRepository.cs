﻿using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Inventory.Domain.Model.Aggregates;
using WebApplication1.Inventory.Domain.Model.ValueObjects;
using WebApplication1.Inventory.Domain.Repositories;
using WebApplication1.Shared.Infrastructure.Persistence.EFC.Configuration;
using WebApplication1.Shared.Infrastructure.Persistence.Repositories;

namespace WebApplication1.Inventory.Infrastructure.Persistence.EFC.Repositories
{
    /// <summary>
    /// Repository implementation for Thing operations.
    /// </summary>
    /// <remarks>Fernando Lizano</remarks>
    public class ThingRepository : BaseRepository<Thing>, IThingRepository
    {
        public ThingRepository(AppDbContext context) : base(context) { }

        public async Task<Thing> FindBySerialNumberAsync(SerialNumber serialNumber)
        {
            return await _context.Set<Thing>()
                .FirstOrDefaultAsync(t => t.SerialNumber.Value == serialNumber.Value);
        }

        public async Task<bool> ExistsBySerialNumberAsync(SerialNumber serialNumber)
        {
            return await _context.Set<Thing>()
                .AnyAsync(t => t.SerialNumber.Value == serialNumber.Value);
        }
    }
}