﻿using System.Threading.Tasks;
using WebApplication1.Inventory.Domain.Model.Aggregates;
using WebApplication1.Inventory.Domain.Model.ValueObjects;
using WebApplication1.Shared.Domain.Repositories;

namespace WebApplication1.Inventory.Domain.Repositories
{
    /// <summary>
    /// Repository interface for Thing operations.
    /// </summary>
    /// <remarks>Fernando Lizano</remarks>
    public interface IThingRepository : IBaseRepository<Thing>
    {
        Task<Thing> FindBySerialNumberAsync(SerialNumber serialNumber);
        Task<bool> ExistsBySerialNumberAsync(SerialNumber serialNumber);
    }
}