﻿using System;

namespace WebApplication1.Inventory.Domain.Exceptions
{
    /// <summary>
    /// Custom exception for the Inventory domain.
    /// </summary>
    /// <remarks>Fernando Lizano</remarks>
    public class InventoryDomainException : Exception
    {
        public InventoryDomainException() { }
        public InventoryDomainException(string message) : base(message) { }
        public InventoryDomainException(string message, Exception inner) : base(message, inner) { }
    }
}