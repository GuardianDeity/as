﻿using System;
using System.ComponentModel.DataAnnotations;
using WebApplication1.Inventory.Domain.Exceptions;
using WebApplication1.Inventory.Domain.Model.ValueObjects;

namespace WebApplication1.Inventory.Domain.Model.Aggregates
{
    /// <summary>
    /// Represents a Thing in the IRRIOT system.
    /// </summary>
    /// <remarks>Fernando Lizano</remarks>
    public class Thing : AuditableModel
    {
        public int Id { get; private set; }
        public SerialNumber SerialNumber { get; private set; }
        
        [Required]
        [StringLength(100)]
        public string Model { get; private set; }
        
        public EOperationMode OperationMode { get; private set; }
        
        [Range(-40.00, 85.00)]
        public decimal MaximumTemperatureThreshold { get; private set; }
        
        [Range(0.00, 100.00)]
        public decimal MinimumHumidityThreshold { get; private set; }

        public object CreatedAt { get; set; }
        public object UpdatedAt { get; set; }

        private Thing(object updatedAt)
        {
            UpdatedAt = updatedAt;
        }

        public Thing(string model, decimal maxTemperature, decimal minHumidity, object updatedAt)
        {
            UpdatedAt = updatedAt;
            SetModel(model);
            SetMaximumTemperatureThreshold(maxTemperature);
            SetMinimumHumidityThreshold(minHumidity);
            SerialNumber = SerialNumber.NewSerialNumber();
            OperationMode = EOperationMode.ScheduleDriven;
        }

        public Thing(string commandModel, decimal commandMaximumTemperatureThreshold, decimal commandMinimumHumidityThreshold)
        {
            throw new NotImplementedException();
        }

        public void UpdateOperationMode(EOperationMode newMode)
        {
            OperationMode = newMode;
        }

        private void SetModel(string model)
        {
            if (string.IsNullOrWhiteSpace(model))
                throw new InventoryDomainException("Model cannot be empty or null.");
            if (model.Length > 100)
                throw new InventoryDomainException("Model cannot exceed 100 characters.");
            Model = model;
        }

        private void SetMaximumTemperatureThreshold(decimal maxTemperature)
        {
            if (maxTemperature < -40.00m || maxTemperature > 85.00m)
                throw new InventoryDomainException("Maximum temperature threshold must be between -40.00 and 85.00.");
            MaximumTemperatureThreshold = maxTemperature;
        }

        private void SetMinimumHumidityThreshold(decimal minHumidity)
        {
            if (minHumidity < 0.00m || minHumidity > 100.00m)
                throw new InventoryDomainException("Minimum humidity threshold must be between 0.00 and 100.00.");
            MinimumHumidityThreshold = minHumidity;
        }
    }

    public class AuditableModel
    {
    }
}

