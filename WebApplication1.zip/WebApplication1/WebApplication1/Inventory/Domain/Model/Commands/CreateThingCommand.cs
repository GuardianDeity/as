﻿namespace WebApplication1.Inventory.Domain.Model.Commands
{
    /// <summary>
    /// Command for creating a new Thing.
    /// </summary>
    /// <remarks>Fernando Lizano</remarks>
    public record CreateThingCommand(
        string Model,
        decimal MaximumTemperatureThreshold,
        decimal MinimumHumidityThreshold
    );
}