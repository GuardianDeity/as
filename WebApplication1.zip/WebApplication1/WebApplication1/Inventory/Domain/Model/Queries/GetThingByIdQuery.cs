﻿namespace WebApplication1.Inventory.Domain.Model.Queries
{
    /// <summary>
    /// Query for retrieving a Thing by its ID.
    /// </summary>
    /// <remarks>Fernando Lizano</remarks>
    public record GetThingByIdQuery(int Id);
}