﻿namespace WebApplication1.Inventory.Domain.Model.ValueObjects
{
    /// <summary>
    /// Represents the operation modes supported by IRRIOT devices.
    /// </summary>
    /// <remarks>Fernando Lizano</remarks>
    public enum EOperationMode
    {
        ScheduleDriven = 0,
        TemperatureDriven = 1,
        HumidityDriven = 2
    }
}