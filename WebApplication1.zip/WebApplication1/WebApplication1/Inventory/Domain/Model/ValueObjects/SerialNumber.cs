﻿using System;

namespace WebApplication1.Inventory.Domain.Model.ValueObjects
{
    /// <summary>
    /// Represents a unique serial number for a Thing.
    /// </summary>
    /// <remarks>Fernando Lizano</remarks>
    public record SerialNumber
    {
        public Guid Value { get; }

        private SerialNumber(Guid value)
        {
            Value = value;
        }

        public static SerialNumber NewSerialNumber()
        {
            return new SerialNumber(Guid.NewGuid());
        }

        public static SerialNumber FromGuid(Guid guid)
        {
            return new SerialNumber(guid);
        }

        public override string ToString()
        {
            return Value.ToString();
        }
    }
}