using System.Threading.Tasks;
using WebApplication1.Shared.Domain.Repositories;
using WebApplication1.Shared.Infrastructure.Persistence.EFC.Configuration;

namespace WebApplication1.Shared.Infrastructure.Persistence.Repositories
{
    /// <summary>
    /// Unit of Work implementation for managing transactions.
    /// </summary>
    /// <remarks>Fernando Lizano</remarks>
    public class UnitOfWork : IUnitOfWork
    {
        private readonly AppDbContext _context;

        public UnitOfWork(AppDbContext context)
        {
            _context = context;
        }

        public async Task CompleteAsync()
        {
            await _context.SaveChangesAsync();
        }
    }
}