using Microsoft.EntityFrameworkCore;
using WebApplication1.Inventory.Domain.Model.Aggregates;
using WebApplication1.Inventory.Domain.Model.ValueObjects;

namespace WebApplication1.Shared.Infrastructure.Persistence.EFC.Configuration
{
    /// <summary>
    /// Application database context.
    /// </summary>
    /// <remarks>Fernando Lizano</remarks>
    public class AppDbContext : DbContext
    {
        public DbSet<Thing> Things { get; set; }

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Thing>(entity =>
            {
                entity.ToTable("things");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).HasColumnName("id");
                entity.Property(e => e.SerialNumber).HasConversion(
                    v => v.Value,
                    v => SerialNumber.FromGuid(v)).HasColumnName("serial_number");
                entity.Property(e => e.Model).HasColumnName("model");
                entity.Property(e => e.OperationMode).HasColumnName("operation_mode");
                entity.Property(e => e.MaximumTemperatureThreshold).HasColumnName("maximum_temperature_threshold");
                entity.Property(e => e.MinimumHumidityThreshold).HasColumnName("minimum_humidity_threshold");
                entity.Property(e => e.CreatedAt).HasColumnName("created_at");
                entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            });
        }

        public async Task SaveChangesAsync()
        {
            throw new NotImplementedException();
        }
    }
}