using System.Collections.Generic;
using System.Threading.Tasks;

namespace WebApplication1.Shared.Domain.Repositories
{
    /// <summary>
    /// Base repository interface for common CRUD operations.
    /// </summary>
    /// <remarks>Fernando Lizano</remarks>
    public interface IBaseRepository<T> where T : class
    {
        Task<T> FindByIdAsync(int id);
        Task<IEnumerable<T>> ListAsync();
        Task AddAsync(T entity);
        void Update(T entity);
        void Remove(T entity);
    }
}