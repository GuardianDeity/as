using System.Threading.Tasks;

namespace WebApplication1.Shared.Domain.Repositories
{
    /// <summary>
    /// Unit of Work interface for managing transactions.
    /// </summary>
    /// <remarks>Fernando Lizano</remarks>
    public interface IUnitOfWork
    {
        Task CompleteAsync();
    }
}