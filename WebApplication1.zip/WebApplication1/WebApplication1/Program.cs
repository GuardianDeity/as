using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using WebApplication1.Inventory.Application.ACL;
using WebApplication1.Inventory.Application.Internal.CommandServices;
using WebApplication1.Inventory.Application.Internal.QueryServices;
using WebApplication1.Inventory.Domain.Repositories;
using WebApplication1.Inventory.Infrastructure.Persistence.EFC.Repositories;
using WebApplication1.Inventory.Interfaces.ACL;
using WebApplication1.Shared.Domain.Repositories;
using WebApplication1.Shared.Infrastructure.Interfaces.ASP.Middleware;
using WebApplication1.Shared.Infrastructure.Persistence.EFC.Configuration;
using WebApplication1.Shared.Infrastructure.Persistence.Repositories;

namespace WebApplication1
{
    public class Startup
    {
        public IConfiguration Configuration { get; }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<AppDbContext>(options =>
                options.UseMySql(Configuration.GetConnectionString("DefaultConnection"),
                    new MySqlServerVersion(new Version(8, 0, 21))));

            services.AddScoped<IUnitOfWork, UnitOfWork>();
            services.AddScoped<IThingRepository, ThingRepository>();
            services.AddScoped<CreateThingCommandService>();
            services.AddScoped<GetThingByIdQueryService>();
            services.AddScoped<IInventoryContextFacade, InventoryContextFacade>();

            services.AddControllers();
            services.AddSwaggerGen();
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseMiddleware<GlobalExceptionHandlerMiddleware>();

            app.UseHttpsRedirection();
            app.UseRouting();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}

